# Sheffield Thyroid Cancer Study

This repository contains the [Quarto](https://quarto.org) manuscript for work on the Sheffield Thyroid Cancer Study
which is the PhD work of [Ovie Edafe (mdp21oe)](https://github.com/mdp21oe).
